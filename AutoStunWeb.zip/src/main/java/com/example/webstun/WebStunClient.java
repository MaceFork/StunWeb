package com.example.webstun;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Auto Web Stun (no keybind). Target: Fabric, Minecraft 1.21.4 (Yarn).
 * Idea credit: TikTok @hyper2up "How to web stun".
 *
 * Trigger: you hit a player. The mod then, on its own:
 *   1. swaps to the axe and hits (this disables a raised shield),
 *   2. swaps to cobweb and places it under the target,
 *   3. swaps back to the slot you were holding.
 * Does nothing unless BOTH an axe and cobweb are in the hotbar.
 */
public class WebStunClient implements ClientModInitializer {
    /** true = only fire when the target is holding up a shield. */
    private static final boolean ONLY_VS_SHIELD = false;
    private static final double REACH_SQ = 4.5 * 4.5;

    private int step = 0, wait = 0, cooldown = 0;
    private PlayerEntity target;
    private int origSlot, axeSlot, webSlot;

    @Override
    public void onInitializeClient() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (world.isClient && step == 0 && cooldown == 0
                    && player == mc.player && entity instanceof PlayerEntity t) {
                int ax = find(mc.player, true), wb = find(mc.player, false);
                if (ax >= 0 && wb >= 0 && (!ONLY_VS_SHIELD || t.isBlocking())) {
                    target = t; axeSlot = ax; webSlot = wb;
                    origSlot = mc.player.getInventory().selectedSlot;
                    wait = 0;
                    // already holding the axe? that hit was the shield breaker
                    step = mc.player.getMainHandStack().getItem() instanceof AxeItem ? 3 : 1;
                }
            }
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cooldown > 0) cooldown--;
        if (p == null || mc.interactionManager == null) { step = 0; return; }
        if (step == 0) return;

        if (!target.isAlive() || p.squaredDistanceTo(target) > REACH_SQ) { finish(p); return; }

        switch (step) {
            case 1 -> { p.getInventory().selectedSlot = axeSlot; step = 2; }
            case 2 -> {
                // wait for the axe's cooldown so the hit can break the shield
                if (p.getAttackCooldownProgress(0f) >= 0.9f || ++wait > 30) {
                    mc.interactionManager.attackEntity(p, target);
                    p.swingHand(Hand.MAIN_HAND);
                    step = 3;
                }
            }
            case 3 -> {
                p.getInventory().selectedSlot = webSlot;
                BlockPos feet = target.getBlockPos();
                Vec3d pos = new Vec3d(feet.getX() + 0.5, feet.getY(), feet.getZ() + 0.5);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                        new BlockHitResult(pos, Direction.UP, feet.down(), false));
                p.swingHand(Hand.MAIN_HAND);
                step = 4;
            }
            case 4 -> finish(p);
        }
    }

    private void finish(ClientPlayerEntity p) {
        p.getInventory().selectedSlot = origSlot;
        step = 0;
        cooldown = 20;
    }

    private static int find(ClientPlayerEntity p, boolean axe) {
        for (int i = 0; i < 9; i++) {
            var item = p.getInventory().getStack(i).getItem();
            if (axe ? item instanceof AxeItem : item == Items.COBWEB) return i;
        }
        return -1;
    }
}
