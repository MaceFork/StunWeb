WEB STUN - Fabric mod, Minecraft 1.21.4
Idea credit: TikTok @hyper2up "How to web stun"

BUILD (kailangan: JDK 21 at Gradle 8.12)
1. Buksan ang terminal sa folder na ito.
2. Isang beses lang: gradle wrapper --gradle-version 8.12
3. Windows: gradlew.bat build     Mac/Linux: ./gradlew build
4. Kunin ang webstun-1.0.0.jar sa build/libs/ (HUWAG ang -sources.jar)
5. Ilagay sa .minecraft/mods kasama ang Fabric Loader at Fabric API 1.21.4.

Kung iba ang version mo, palitan ang mga version sa gradle.properties
(kunin ang tamang numbers sa fabricmc.net/develop).
